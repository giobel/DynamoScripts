﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Xml;
using System.Linq;
using Autodesk.Revit;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System.Drawing;
using BHGeneral;
using slvvswc;
using BHViewHelpers;
using Autodesk.Revit.ApplicationServices;
using BHSheetManagementBase;

namespace BHCommands
{
   /// <summary>
   /// Implements the Revit add-in interface IExternalCommand
   /// </summary>
   [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
   [Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Manual)]
   [Autodesk.Revit.Attributes.Journaling(Autodesk.Revit.Attributes.JournalingMode.NoCommandData)]
   #region IExternalCommand Members
   public class BHTestCommand : IExternalCommand
   {
     TimeSpan totalTime, timeViewPortsCreation;
      public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
      {
         return CreateViewPort(commandData);
      }

      public Result CreateViewPort(ExternalCommandData commandData)
      {
        Document thisDoc = commandData.Application.ActiveUIDocument.Document;
        ViewSheet testSheet = null;
        ViewSheet vSheet = thisDoc.ActiveView as ViewSheet;
        if (vSheet == null)
        {
          System.Windows.Forms.MessageBox.Show("The current view is not a sheet");
          return Result.Failed;
        }
        Transaction trans = new Transaction(thisDoc, "createViewSheet");

        try
        {
          //
          // Get title block
          // 
          ICollection<Element> elems = new FilteredElementCollector(thisDoc, thisDoc.ActiveView.Id).OfCategory(BuiltInCategory.OST_TitleBlocks).WhereElementIsNotElementType().ToElements();
          Element e = elems.FirstOrDefault();
          if (e == null) return Result.Failed;
          trans.Start();
          DateTime start = DateTime.Now;
          timeViewPortsCreation = DateTime.Now - DateTime.Now;
          int counter = 3;
          //
          // Create 3 sheets, duplicate the views which are placed on the sheet
          //
          for (int nr = 0; nr < counter; nr++)
          {
            FamilyInstance fi = e as FamilyInstance;
            string s = "testjeroen" + counter;
            ViewSheet vs = thisDoc.ActiveView as ViewSheet;
            testSheet = ViewSheet.Create(thisDoc, fi.Symbol.Id);
            //
            // Deprecated in Revit 2015 so does no longer work in 2016 ;-)
            //
            var vws = vSheet.Views.OfType<View>().ToList();
            for (int i = 0; i < vws.Count; i++)
            {
              //
              // Create a view and place this on the testsheet. It's location does not matter in this test
              //
                XYZ locxyz = new XYZ(0, 0, 0);
                var newview = vws[i].Duplicate(ViewDuplicateOption.WithDetailing);
                CreateViewPort(thisDoc, testSheet, locxyz, newview);
            }
          }
          trans.Commit();
          totalTime = DateTime.Now - start;
          System.Windows.Forms.MessageBox.Show("Total time " + totalTime.TotalSeconds + " time creating viewports took " + timeViewPortsCreation.TotalSeconds);
          return Result.Succeeded;
        }
        catch (Exception ex)
        {
          trans.RollBack();
          return Result.Failed;
        }
      }

      private void CreateViewPort(Document thisDoc, ViewSheet testSheet, XYZ locxyz, ElementId newview)
      {
        DateTime t1 = DateTime.Now;
        var v1 = Viewport.Create(thisDoc, testSheet.Id, newview, locxyz);
        TimeSpan ts1 = DateTime.Now - t1;
        timeViewPortsCreation = timeViewPortsCreation + ts1;
      }
   }
   #endregion
}
