#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
#endregion

namespace ViewportCreateBenchmark
{
  [Transaction( TransactionMode.Manual )]
  public class Command : IExternalCommand
  {
#if BOILERPLATE
    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      UIApplication uiapp = commandData.Application;
      UIDocument uidoc = uiapp.ActiveUIDocument;
      Application app = uiapp.Application;
      Document doc = uidoc.Document;

      // Access current selection

      Selection sel = uidoc.Selection;

      // Retrieve elements from database

      FilteredElementCollector col
        = new FilteredElementCollector( doc )
          .WhereElementIsNotElementType()
          .OfCategory( BuiltInCategory.INVALID )
          .OfClass( typeof( Wall ) );

      // Filtered element collector is iterable

      foreach( Element e in col )
      {
        Debug.Print( e.Name );
      }

      // Modify document within a transaction

      using( Transaction tx = new Transaction( doc ) )
      {
        tx.Start( "Transaction Name" );
        tx.Commit();
      }

      return Result.Succeeded;
    }
#endif // BOILERPLATE

    TimeSpan totalTime, timeViewPortsCreation;

    public Result Execute( 
      ExternalCommandData commandData, 
      ref string message, 
      ElementSet elements )
    {
      Document doc = commandData.Application.ActiveUIDocument.Document;
      ViewSheet testSheet = null;
      ViewSheet vSheet = doc.ActiveView as ViewSheet;
      
      if( vSheet == null )
      {
        message = "The current view is not a sheet";
        return Result.Failed;
      }

      Element e = new FilteredElementCollector( doc, 
          doc.ActiveView.Id )
        .OfCategory( BuiltInCategory.OST_TitleBlocks )
        .WhereElementIsNotElementType()
        .FirstElement();

      if( e == null )
      {
        message = "No title blo";
        return Result.Failed;
      }

      Result rc = Result.Failed;

      using( Transaction trans = new Transaction( doc ) )
      {
        trans.Start("Create View Sheet");
        DateTime start = DateTime.Now;
        timeViewPortsCreation = DateTime.Now - DateTime.Now;
        int counter = 3;

        // Create 3 sheets, duplicate the views which are placed on the sheet

        for( int nr = 0; nr < counter; nr++ )
        {
          FamilyInstance fi = e as FamilyInstance;
          string s = "testjeroen" + counter;
          ViewSheet vs = doc.ActiveView as ViewSheet;
          testSheet = ViewSheet.Create( doc, fi.Symbol.Id );

          // Deprecated in Revit 2015 so does no longer work in 2016 ;-)
          //var vws = vSheet.Views.OfType<View>().ToList();

          var ids = vSheet.GetAllPlacedViews();

          foreach( ElementId id in ids )
          {
            View view = doc.GetElement( id ) as View;

            // Create a view and place this on the testsheet. 
            // Its location does not matter in this test.

            XYZ locxyz = XYZ.Zero;
            var newview = view.Duplicate( ViewDuplicateOption.WithDetailing );
            CreateViewPort( doc, testSheet, locxyz, newview );
          }
        }
        trans.Commit();
        totalTime = DateTime.Now - start;
        TaskDialog.Show( "Viewport Create Benchmark",
          "Total time " + totalTime.TotalSeconds 
          + " time creating viewports took " 
          + timeViewPortsCreation.TotalSeconds );
        rc = Result.Succeeded;
      }
      return rc;
    }

    private void CreateViewPort( 
      Document doc, 
      ViewSheet testSheet, 
      XYZ locxyz, 
      ElementId newview )
    {
      DateTime t1 = DateTime.Now;
      var v1 = Viewport.Create( doc, testSheet.Id, newview, locxyz );
      TimeSpan ts1 = DateTime.Now - t1;
      timeViewPortsCreation = timeViewPortsCreation + ts1;
    }
  }
}
